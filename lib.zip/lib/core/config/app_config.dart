// Copiez ce fichier en app_config.dart et remplissez vos valeurs

class AppConfig {
  /// Vérifie que les clés Supabase sont bien renseignées.
  static void validate() {
    assert(supabaseUrl != 'https://mkrbhyrkrajicthcqjtj.supabase.co', 'AppConfig: supabaseUrl non configuré');
    assert(supabaseAnonKey != 'sb_publishable_UyjVexlQkh_qO0yiPoiTuA_eJfdz23w', 'AppConfig: supabaseAnonKey non configuré');
  }

  static const String supabaseUrl     = 'https://mkrbhyrkrajicthcqjtj.supabase.co';
  static const String supabaseAnonKey = 'sb_publishable_UyjVexlQkh_qO0yiPoiTuA_eJfdz23w';
}