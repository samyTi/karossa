// lib/core/config/app_config.dart
// ⚠️  Ce fichier doit être dans .gitignore
//
// Les valeurs sont lues depuis --dart-define à la compilation.
// En développement, créez un script run.sh :
//
//   flutter run \
//     --dart-define=SUPABASE_URL=https://xxx.supabase.co \
//     --dart-define=SUPABASE_ANON_KEY=sb_publishable_xxx
//
// En CI/CD, injectez les variables depuis les secrets (GitHub Actions, etc.)

class AppConfig {
  const AppConfig._();

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: '',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: '',
  );

  /// Valide la configuration au démarrage (appeler dans main())
  static void validate() {
    assert(
      supabaseUrl.isNotEmpty,
      '\n\n❌ SUPABASE_URL manquant.\n'
      'Lancez : flutter run --dart-define=SUPABASE_URL=https://xxx.supabase.co\n',
    );
    assert(
      supabaseAnonKey.isNotEmpty,
      '\n\n❌ SUPABASE_ANON_KEY manquant.\n'
      'Lancez : flutter run --dart-define=SUPABASE_ANON_KEY=sb_publishable_xxx\n',
    );
  }
}
