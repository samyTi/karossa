import 'package:supabase_flutter/supabase_flutter.dart';
import '../domain/contract_article_model.dart';
import '../../../core/utils/app_logger.dart';

class ContractArticlesRepository {
  ContractArticlesRepository(this._client);
  final SupabaseClient _client;

  Future<List<ContractArticle>> getActifs(String contratType) async {
    try {
      final data = await _client
          .from('contract_articles')
          .select()
          .eq('contrat_type', contratType)
          .eq('actif', true)
          .order('ordre');
      return (data as List).map((j) => ContractArticle.fromJson(j)).toList();
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.getActifs: $e');
      return [];
    }
  }

  Future<List<ContractArticle>> getTous(String contratType) async {
    try {
      final data = await _client
          .from('contract_articles')
          .select()
          .eq('contrat_type', contratType)
          .order('ordre');
      return (data as List).map((j) => ContractArticle.fromJson(j)).toList();
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.getTous: $e');
      return [];
    }
  }

  Future<ContractArticle?> creer(ContractArticle article) async {
    try {
      final json = article.toJson();
      // On retire l'ID vide pour laisser Supabase générer l'UUID
      if (article.id.isEmpty) {
        json.remove('id');
      }
      
      final data = await _client
          .from('contract_articles')
          .insert(json)
          .select()
          .single();
          
      return ContractArticle.fromJson(data);
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.creer erreur: $e');
      rethrow; // Important pour que le Notifier puisse attraper l'erreur
    }
  }

  Future<bool> modifier(String id, Map<String, dynamic> data) async {
    try {
      await _client
          .from('contract_articles')
          .update({...data, 'updated_at': DateTime.now().toIso8601String()})
          .eq('id', id);
      return true;
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.modifier: $e');
      rethrow;
    }
  }

  Future<bool> toggleActif(String id, bool actif) =>
      modifier(id, {'actif': actif});

  Future<bool> reordonner(List<ContractArticle> articles) async {
    try {
      // Utilisation de Future.wait pour paralléliser les updates d'ordre
      await Future.wait(
        articles.asMap().entries.map((entry) => 
          _client.from('contract_articles')
            .update({'ordre': entry.key})
            .eq('id', entry.value.id)
        )
      );
      return true;
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.reordonner: $e');
      return false;
    }
  }

  Future<bool> supprimer(String id) async {
    try {
      await _client.from('contract_articles').delete().eq('id', id);
      return true;
    } catch (e) {
      AppLogger.d('ContractArticlesRepository.supprimer: $e');
      rethrow;
    }
  }
  Future<List<Map<String, String>>> getArticlesResolus({
    required String contratType,
    required Map<String, dynamic> contextData,
  }) async {
    final articles = await getActifs(contratType);
    
    // On s'assure que toutes les valeurs du contexte sont des Strings
    final strContext = contextData.map(
      (k, v) => MapEntry(k, v?.toString() ?? ''),
    );

    return articles
        .where((a) => a.evaluerCondition(contextData))
        .map((a) => {
              'titre': a.resolveTitre(strContext),
              'corps': a.resolveVariables(strContext),
            })
        .toList();
  }
}