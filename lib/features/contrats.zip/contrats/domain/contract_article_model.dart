// lib/features/contrats/domain/contract_article_model.dart

class ContractArticle {
  final String id;
  final String contratType; // 'location' | 'vente' | 'echange'
  final String titre;
  final String corps;
  final int ordre;
  final bool obligatoire;
  final bool actif;
  final Map<String, dynamic>? conditionJson;
  final DateTime createdAt;
  final DateTime updatedAt;

  const ContractArticle({
    required this.id,
    required this.contratType,
    required this.titre,
    required this.corps,
    required this.ordre,
    this.obligatoire = false,
    this.actif = true,
    this.conditionJson,
    required this.createdAt,
    required this.updatedAt,
  });

  factory ContractArticle.fromJson(Map<String, dynamic> json) => ContractArticle(
        id: json['id'] as String,
        contratType: json['contrat_type'] as String,
        titre: json['titre'] as String,
        corps: json['corps'] as String,
        ordre: json['ordre'] as int? ?? 0,
        obligatoire: json['obligatoire'] as bool? ?? false,
        actif: json['actif'] as bool? ?? true,
        conditionJson: json['condition_json'] != null
            ? Map<String, dynamic>.from(json['condition_json'])
            : null,
        createdAt: DateTime.parse(json['created_at'] as String),
        updatedAt: DateTime.parse(json['updated_at'] as String),
      );

  Map<String, dynamic> toJson() => {
        'contrat_type': contratType,
        'titre': titre,
        'corps': corps,
        'ordre': ordre,
        'obligatoire': obligatoire,
        'actif': actif,
        'condition_json': conditionJson,
      };

  ContractArticle copyWith({
    String? titre,
    String? corps,
    int? ordre,
    bool? obligatoire,
    bool? actif,
    Map<String, dynamic>? conditionJson,
  }) =>
      ContractArticle(
        id: id,
        contratType: contratType,
        titre: titre ?? this.titre,
        corps: corps ?? this.corps,
        ordre: ordre ?? this.ordre,
        obligatoire: obligatoire ?? this.obligatoire,
        actif: actif ?? this.actif,
        conditionJson: conditionJson ?? this.conditionJson,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );

  /// Résout les {{variables}} avec les données fournies.
  /// Ex : resolveVariables({'client_nom': 'Karim', 'prix_vente': '1 500 000'})
  String get corpsResolu => corps; // brut — utilisé dans l'admin
  String resolveVariables(Map<String, String> data) {
    var result = corps;
    data.forEach((key, value) {
      result = result.replaceAll('{{$key}}', value);
    });
    return result;
  }

  String resolveTitre(Map<String, String> data) {
    var result = titre;
    data.forEach((key, value) {
      result = result.replaceAll('{{$key}}', value);
    });
    return result;
  }

  /// Évalue la condition d'affichage si elle existe.
  /// Condition JSON format : {'champ': 'prix_vente', 'op': '>', 'valeur': 500000}
  bool evaluerCondition(Map<String, dynamic> contextData) {
    if (conditionJson == null) return true;
    try {
      final champ = conditionJson!['champ'] as String;
      final op = conditionJson!['op'] as String;
      final valeur = conditionJson!['valeur'];
      final contextVal = contextData[champ];
      if (contextVal == null) return false;
      final cv = num.tryParse(contextVal.toString()) ?? 0;
      final vv = num.tryParse(valeur.toString()) ?? 0;
      switch (op) {
        case '>': return cv > vv;
        case '>=': return cv >= vv;
        case '<': return cv < vv;
        case '<=': return cv <= vv;
        case '==': return cv == vv || contextVal.toString() == valeur.toString();
        case '!=': return cv != vv;
        default: return true;
      }
    } catch (_) {
      return true;
    }
  }
}