import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/theme/app_text_styles.dart';
// Correction de l'import : on remonte d'un dossier vers presentation/
import './contract_articles_provider.dart'; 
// Correction de l'import : on remonte vers features/contrats/puis domain/
import '../domain/contract_article_model.dart';

class ContractArticlesAdminScreen extends ConsumerStatefulWidget {
  const ContractArticlesAdminScreen({super.key});

  @override
  ConsumerState<ContractArticlesAdminScreen> createState() =>
      _ContractArticlesAdminScreenState();
}

class _ContractArticlesAdminScreenState
    extends ConsumerState<ContractArticlesAdminScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _types = ['location', 'vente', 'echange'];
  final _typesLabels = ['Location', 'Vente', 'Échange'];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: _types.length, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Articles des contrats'),
        bottom: TabBar(
          controller: _tabController,
          tabs: _typesLabels.map((l) => Tab(text: l)).toList(),
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: _types.map((type) => _ArticlesTab(contratType: type)).toList(),
      ),
    );
  }
}

class _ArticlesTab extends ConsumerWidget {
  const _ArticlesTab({required this.contratType});
  final String contratType;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncArticles = ref.watch(contractArticlesNotifierProvider(contratType));

    return asyncArticles.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('Erreur : $e')),
      data: (articles) => _ArticlesList(
        contratType: contratType,
        articles: articles,
      ),
    );
  }
}

class _ArticlesList extends ConsumerStatefulWidget {
  const _ArticlesList({required this.contratType, required this.articles});
  final String contratType;
  final List<ContractArticle> articles;

  @override
  ConsumerState<_ArticlesList> createState() => _ArticlesListState();
}

class _ArticlesListState extends ConsumerState<_ArticlesList> {
  void _onReorder(int oldIndex, int newIndex) {
    final list = List<ContractArticle>.from(widget.articles);
    if (newIndex > oldIndex) newIndex--;
    final item = list.removeAt(oldIndex);
    list.insert(newIndex, item);
    
    ref.read(contractArticlesNotifierProvider(widget.contratType).notifier)
       .reordonner(list);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: widget.articles.isEmpty
          ? _EmptyState(contratType: widget.contratType)
          : ReorderableListView.builder(
              padding: const EdgeInsets.only(bottom: 80, top: 8),
              itemCount: widget.articles.length,
              onReorder: _onReorder,
              itemBuilder: (_, i) => _ArticleCard(
                key: ValueKey(widget.articles[i].id),
                article: widget.articles[i],
                contratType: widget.contratType,
              ),
            ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showForm(context, null),
        icon: const Icon(Icons.add),
        label: const Text('Nouvel article'),
      ),
    );
  }

  void _showForm(BuildContext context, ContractArticle? existing) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (_) => _ArticleForm(
        contratType: widget.contratType,
        existing: existing,
      ),
    );
  }
}

class _ArticleCard extends ConsumerWidget {
  const _ArticleCard({super.key, required this.article, required this.contratType});
  final ContractArticle article;
  final String contratType;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.read(contractArticlesNotifierProvider(contratType).notifier);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      child: ListTile(
        leading: const Icon(Icons.drag_handle),
        title: Text(article.titre, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(article.corps, maxLines: 1, overflow: TextOverflow.ellipsis),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Switch.adaptive(
              value: article.actif,
              onChanged: (v) => notifier.toggleActif(article.id, v),
            ),
            IconButton(
              icon: const Icon(Icons.edit_outlined),
              onPressed: () => showModalBottomSheet(
                context: context,
                isScrollControlled: true,
                useSafeArea: true,
                builder: (_) => _ArticleForm(contratType: contratType, existing: article),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.red),
              onPressed: () => _confirmDelete(context, notifier),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _confirmDelete(BuildContext context, dynamic notifier) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Supprimer ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Non')),
          TextButton(onPressed: () => Navigator.pop(context, true), child: const Text('Oui')),
        ],
      ),
    );
    if (ok == true) notifier.supprimer(article.id);
  }
}

class _ArticleForm extends ConsumerStatefulWidget {
  const _ArticleForm({required this.contratType, this.existing});
  final String contratType;
  final ContractArticle? existing;

  @override
  ConsumerState<_ArticleForm> createState() => _ArticleFormState();
}

class _ArticleFormState extends ConsumerState<_ArticleForm> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titreCtrl;
  late TextEditingController _corpsCtrl;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _titreCtrl = TextEditingController(text: widget.existing?.titre ?? '');
    _corpsCtrl = TextEditingController(text: widget.existing?.corps ?? '');
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);

    try {
      final notifier = ref.read(contractArticlesNotifierProvider(widget.contratType).notifier);
      if (widget.existing == null) {
        await notifier.creer(ContractArticle(
          id: '',
          contratType: widget.contratType,
          titre: _titreCtrl.text.trim(),
          corps: _corpsCtrl.text.trim(),
          ordre: 0,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        ));
      } else {
        await notifier.modifier(widget.existing!.id, {
          'titre': _titreCtrl.text.trim(),
          'corps': _corpsCtrl.text.trim(),
        });
      }
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Erreur : $e'), backgroundColor: Colors.red),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, left: 16, right: 16, top: 16),
      child: Form(
        key: _formKey,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextFormField(controller: _titreCtrl, decoration: const InputDecoration(labelText: 'Titre')),
            const SizedBox(height: 16),
            TextFormField(controller: _corpsCtrl, maxLines: 5, decoration: const InputDecoration(labelText: 'Corps')),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton(
                onPressed: _saving ? null : _save,
                child: _saving ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)) : const Text('Enregistrer'),
              ),
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.contratType});
  final String contratType;
  @override
  Widget build(BuildContext context) => const Center(child: Text('Aucun article trouvé.'));
}