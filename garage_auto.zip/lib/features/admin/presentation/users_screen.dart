import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';
import '../../../shared/widgets/custom_app_bar.dart';
import '../../auth/domain/profile_model.dart';

class UsersScreen extends ConsumerWidget {
  const UsersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // Sample users data (in a real app, this would come from a repository)
    final users = [
      UserData(
        id: '1',
        nom: 'Ben Ali',
        prenom: 'Ahmed',
        email: 'ahmed.benali@showroom.tn',
        role: UserRole.gerant,
        actif: true,
      ),
      UserData(
        id: '2',
        nom: 'Mansouri',
        prenom: 'Fatma',
        email: 'fatma.mansouri@showroom.tn',
        role: UserRole.proprietaire_showroom,
        actif: true,
      ),
      UserData(
        id: '3',
        nom: 'Trabelsi',
        prenom: 'Mohamed',
        email: 'mohamed.trabelsi@showroom.tn',
        role: UserRole.proprietaire_vehicule,
        actif: true,
      ),
      UserData(
        id: '4',
        nom: 'Gharbi',
        prenom: 'Leila',
        email: 'leila.gharbi@showroom.tn',
        role: UserRole.admin,
        actif: false,
      ),
    ];

    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Gérer les utilisateurs',
        showBackButton: true,
        showHomeButton: true,
      ),
      body: Column(
        children: [
          // Stats bar
          Container(
            padding: const EdgeInsets.all(16),
            margin: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: AppColors.primary.withOpacity(0.2),
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _StatItem(
                  label: 'Total',
                  value: '${users.length}',
                  icon: Icons.people,
                  color: AppColors.primary,
                ),
                _StatItem(
                  label: 'Actifs',
                  value: '${users.where((u) => u.actif).length}',
                  icon: Icons.check_circle,
                  color: AppColors.secondary,
                ),
                _StatItem(
                  label: 'Inactifs',
                  value: '${users.where((u) => !u.actif).length}',
                  icon: Icons.cancel,
                  color: AppColors.textSecondary,
                ),
              ],
            ),
          ),

          // Users list
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: users.length,
              itemBuilder: (context, index) {
                final user = users[index];
                return _UserCard(
                  user: user,
                  onEdit: () {
                    // TODO: Navigate to edit user screen
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Édition utilisateur...')),
                    );
                  },
                  onToggleActive: () {
                    // TODO: Toggle user active status
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(
                          'Utilisateur ${user.actif ? 'désactivé' : 'réactivé'}',
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          // TODO: Show add user dialog
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Ajouter un utilisateur...')),
          );
        },
        icon: const Icon(Icons.person_add),
        label: const Text('Ajouter'),
        backgroundColor: AppColors.primary,
      ),
    );
  }
}

class UserData {
  final String id, nom, prenom, email;
  final UserRole role;
  final bool actif;

  UserData({
    required this.id,
    required this.nom,
    required this.prenom,
    required this.email,
    required this.role,
    required this.actif,
  });
}

class _StatItem extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatItem({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) => Column(
    children: [
      Icon(icon, color: color, size: 24),
      const SizedBox(height: 4),
      Text(
        value,
        style: TextStyle(
          fontSize: 22,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
      const SizedBox(height: 2),
      Text(
        label,
        style: AppTextStyles.label.copyWith(color: color),
      ),
    ],
  );
}

class _UserCard extends StatelessWidget {
  final UserData user;
  final VoidCallback onEdit;
  final VoidCallback onToggleActive;

  const _UserCard({
    required this.user,
    required this.onEdit,
    required this.onToggleActive,
  });

  @override
  Widget build(BuildContext context) {
    final roleColor = user.role.color;
    final roleLabel = user.role.label;

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            // Avatar
            CircleAvatar(
              radius: 24,
              backgroundColor: roleColor.withOpacity(0.15),
              child: Text(
                '${user.prenom[0]}${user.nom[0]}',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: roleColor,
                ),
              ),
            ),
            const SizedBox(width: 12),

            // Info
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${user.prenom} ${user.nom}',
                    style: AppTextStyles.heading3,
                  ),
                  const SizedBox(height: 2),
                  Text(
                    user.email,
                    style: AppTextStyles.bodySecondary.copyWith(fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                       Container(
                         padding: const EdgeInsets.symmetric(
                           horizontal: 8,
                           vertical: 2,
                         ),
                         decoration: BoxDecoration(
                           color: roleColor.withOpacity(0.1),
                           borderRadius: BorderRadius.circular(8),
                           border: Border.all(
                             color: roleColor.withOpacity(0.3),
                           ),
                         ),
                         child: Text(
                           roleLabel,
                           style: TextStyle(
                             fontSize: 11,
                             fontWeight: FontWeight.bold,
                             color: roleColor,
                           ),
                         ),
                       ),
                      if (!user.actif) ...[
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: AppColors.retard.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(
                              color: AppColors.retard.withOpacity(0.3),
                            ),
                          ),
                          child: const Text(
                            'Inactif',
                            style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: AppColors.retard,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),

            // Actions
            PopupMenuButton<String>(
              onSelected: (value) {
                if (value == 'edit') {
                  onEdit();
                } else if (value == 'toggle') {
                  onToggleActive();
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: 'edit',
                  child: Row(
                    children: [
                      Icon(Icons.edit, size: 18),
                      SizedBox(width: 8),
                      Text('Modifier'),
                    ],
                  ),
                ),
                PopupMenuItem(
                  value: 'toggle',
                  child: Row(
                    children: [
                      Icon(
                        user.actif ? Icons.block : Icons.check_circle,
                        size: 18,
                        color: user.actif ? AppColors.retard : AppColors.secondary,
                      ),
                      const SizedBox(width: 8),
                      Text(user.actif ? 'Désactiver' : 'Réactiver'),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}