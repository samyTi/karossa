// lib/features/gps/data/traccar_service.dart
// Client HTTP + WebSocket pour l'API Traccar

import 'dart:convert';
import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:web_socket_channel/web_socket_channel.dart';
import '../domain/gps_models.dart';

class TraccarService {
  // ── Singleton ──────────────────────────────────────────────
  static final TraccarService _instance = TraccarService._internal();
  factory TraccarService() => _instance;
  TraccarService._internal();

  // ══ CONFIGURATION ══════════════════════════════════════════
  // Remplacez ces valeurs par votre serveur Traccar
  static const String _baseUrl  = 'https://demo.traccar.org';
  static const String _user     = 'dilemsalesforce@gmail.com;
  static const String _password = 'Traccar2026';

  // ── Internals ──────────────────────────────────────────────
  WebSocketChannel? _wsChannel;
  StreamController<Map<String, dynamic>>? _wsController;
  final Map<int, TraccarPosition> _lastPositions = {};
  final Map<int, TraccarDevice>   _devices       = {};

  // Auth header Basic
  String get _authHeader {
    final creds = base64Encode(utf8.encode('$_user:$_password'));
    return 'Basic $creds';
  }

  Map<String, String> get _headers => {
    'Authorization': _authHeader,
    'Content-Type':  'application/json',
    'Accept':        'application/json',
  };

  // ══ DEVICES ═══════════════════════════════════════════════

  /// Récupère tous les boîtiers GPS
  Future<List<TraccarDevice>> getDevices() async {
    try {
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/devices'),
        headers: _headers,
      );
      if (resp.statusCode != 200) throw Exception('Erreur ${resp.statusCode}');
      final List data = jsonDecode(resp.body);
      final devices = data.map((j) => TraccarDevice.fromJson(j)).toList();
      for (final d in devices) { _devices[d.id] = d; }
      return devices;
    } catch (e) {
      debugPrint('TraccarService.getDevices: $e');
      return [];
    }
  }

  /// Récupère un boîtier par immatriculation (uniqueId)
  Future<TraccarDevice?> getDeviceByImmat(String immat) async {
    final devices = await getDevices();
    try {
      return devices.firstWhere((d) => d.uniqueId == immat);
    } catch (_) {
      return null;
    }
  }

  // ══ POSITIONS ═════════════════════════════════════════════

  /// Positions actuelles de tous les boîtiers
  Future<List<TraccarPosition>> getAllPositions() async {
    try {
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/positions'),
        headers: _headers,
      );
      if (resp.statusCode != 200) throw Exception('Erreur ${resp.statusCode}');
      final List data = jsonDecode(resp.body);
      final positions = data.map((j) => TraccarPosition.fromJson(j)).toList();
      for (final p in positions) { _lastPositions[p.deviceId] = p; }
      return positions;
    } catch (e) {
      debugPrint('TraccarService.getAllPositions: $e');
      return [];
    }
  }

  /// Position actuelle d'un boîtier spécifique
  Future<TraccarPosition?> getPositionForDevice(int deviceId) async {
    try {
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/positions?deviceId=$deviceId'),
        headers: _headers,
      );
      if (resp.statusCode != 200) return null;
      final List data = jsonDecode(resp.body);
      if (data.isEmpty) return null;
      final pos = TraccarPosition.fromJson(data.first);
      _lastPositions[deviceId] = pos;
      return pos;
    } catch (e) {
      debugPrint('TraccarService.getPositionForDevice: $e');
      return null;
    }
  }

  /// Dernière position connue (cache local)
  TraccarPosition? getCachedPosition(int deviceId) => _lastPositions[deviceId];

  // ══ WEBSOCKET LIVE ════════════════════════════════════════

  /// Démarre l'écoute WebSocket (positions + événements en temps réel)
  Stream<Map<String, dynamic>> startLiveTracking() {
    _wsController?.close();
    _wsController = StreamController<Map<String, dynamic>>.broadcast();

    final wsUrl = _baseUrl
        .replaceFirst('http://', 'ws://')
        .replaceFirst('https://', 'wss://');

    try {
      _wsChannel = WebSocketChannel.connect(
        Uri.parse('$wsUrl/api/socket'),
        protocols: ['Basic ${base64Encode(utf8.encode("$_user:$_password"))}'],
      );

      _wsChannel!.stream.listen(
        (data) {
          try {
            final json = jsonDecode(data as String) as Map<String, dynamic>;
            // Mise en cache des positions reçues en live
            if (json.containsKey('positions')) {
              for (final p in (json['positions'] as List)) {
                final pos = TraccarPosition.fromJson(p);
                _lastPositions[pos.deviceId] = pos;
              }
            }
            _wsController?.add(json);
          } catch (_) {}
        },
        onError: (e) {
          debugPrint('WebSocket error: $e');
          _wsController?.addError(e);
        },
        onDone: () {
          debugPrint('WebSocket fermé');
          _wsController?.close();
        },
      );
    } catch (e) {
      debugPrint('TraccarService.startLiveTracking: $e');
    }

    return _wsController!.stream;
  }

  void stopLiveTracking() {
    _wsChannel?.sink.close();
    _wsChannel = null;
    _wsController?.close();
    _wsController = null;
  }

  // ══ RAPPORTS ══════════════════════════════════════════════

  /// Historique des trajets d'un boîtier
  Future<List<TraccarTrip>> getTrips({
    required int deviceId,
    required DateTime from,
    required DateTime to,
  }) async {
    try {
      final fromStr = from.toUtc().toIso8601String();
      final toStr   = to.toUtc().toIso8601String();
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/reports/trips'
            '?deviceId=$deviceId&from=$fromStr&to=$toStr'),
        headers: _headers,
      );
      if (resp.statusCode != 200) return [];
      final List data = jsonDecode(resp.body);
      return data.map((j) => TraccarTrip.fromJson(j)).toList();
    } catch (e) {
      debugPrint('TraccarService.getTrips: $e');
      return [];
    }
  }

  /// Historique complet des positions (pour dessiner la route)
  Future<List<TraccarPosition>> getPositionsHistory({
    required int deviceId,
    required DateTime from,
    required DateTime to,
  }) async {
    try {
      final fromStr = from.toUtc().toIso8601String();
      final toStr   = to.toUtc().toIso8601String();
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/positions'
            '?deviceId=$deviceId&from=$fromStr&to=$toStr'),
        headers: _headers,
      );
      if (resp.statusCode != 200) return [];
      final List data = jsonDecode(resp.body);
      return data.map((j) => TraccarPosition.fromJson(j)).toList();
    } catch (e) {
      debugPrint('TraccarService.getPositionsHistory: $e');
      return [];
    }
  }

  /// Résumé kilométrique d'un boîtier sur une période
  Future<Map<String, dynamic>> getKmSummary({
    required int deviceId,
    required DateTime from,
    required DateTime to,
  }) async {
    try {
      final fromStr = from.toUtc().toIso8601String();
      final toStr   = to.toUtc().toIso8601String();
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/reports/summary'
            '?deviceId=$deviceId&from=$fromStr&to=$toStr'),
        headers: _headers,
      );
      if (resp.statusCode != 200) return {};
      final List data = jsonDecode(resp.body);
      return data.isNotEmpty ? data.first : {};
    } catch (e) {
      debugPrint('TraccarService.getKmSummary: $e');
      return {};
    }
  }

  // ══ ÉVÉNEMENTS ════════════════════════════════════════════

  Future<List<TraccarEvent>> getEvents({
    required int deviceId,
    required DateTime from,
    required DateTime to,
    List<String>? types,
  }) async {
    try {
      final fromStr = from.toUtc().toIso8601String();
      final toStr   = to.toUtc().toIso8601String();
      String url = '$_baseUrl/api/reports/events'
          '?deviceId=$deviceId&from=$fromStr&to=$toStr';
      if (types != null) {
        url += '&' + types.map((t) => 'type=$t').join('&');
      }
      final resp = await http.get(Uri.parse(url), headers: _headers);
      if (resp.statusCode != 200) return [];
      final List data = jsonDecode(resp.body);
      return data.map((j) => TraccarEvent.fromJson(j)).toList();
    } catch (e) {
      debugPrint('TraccarService.getEvents: $e');
      return [];
    }
  }

  // ══ GEOFENCES ═════════════════════════════════════════════

  Future<List<TraccarGeofence>> getGeofences() async {
    try {
      final resp = await http.get(
        Uri.parse('$_baseUrl/api/geofences'),
        headers: _headers,
      );
      if (resp.statusCode != 200) return [];
      final List data = jsonDecode(resp.body);
      return data.map((j) => TraccarGeofence.fromJson(j)).toList();
    } catch (e) {
      debugPrint('TraccarService.getGeofences: $e');
      return [];
    }
  }

  /// Crée une zone circulaire autour d'un point
  Future<TraccarGeofence?> createCircleGeofence({
    required String name,
    required double lat,
    required double lon,
    required double radiusMeters,
    String description = '',
  }) async {
    try {
      final area = 'CIRCLE ($lat $lon, $radiusMeters)';
      final body = jsonEncode({
        'name':        name,
        'description': description,
        'area':        area,
      });
      final resp = await http.post(
        Uri.parse('$_baseUrl/api/geofences'),
        headers: _headers,
        body: body,
      );
      if (resp.statusCode != 200) return null;
      return TraccarGeofence.fromJson(jsonDecode(resp.body));
    } catch (e) {
      debugPrint('TraccarService.createCircleGeofence: $e');
      return null;
    }
  }

  /// Associe un boîtier à une geofence
  Future<bool> linkDeviceToGeofence(int deviceId, int geofenceId) async {
    try {
      final resp = await http.post(
        Uri.parse('$_baseUrl/api/permissions'),
        headers: _headers,
        body: jsonEncode({
          'deviceId':    deviceId,
          'geofenceId':  geofenceId,
        }),
      );
      return resp.statusCode == 204;
    } catch (e) {
      debugPrint('TraccarService.linkDeviceToGeofence: $e');
      return false;
    }
  }

  void dispose() {
    stopLiveTracking();
  }
}
