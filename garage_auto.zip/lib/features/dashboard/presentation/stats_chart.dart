import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';

class RevenusChart extends StatelessWidget {
  final List<double> revenus;   // 12 valeurs (Jan → Déc)
  final List<double> depenses;  // 12 valeurs
  const RevenusChart({super.key, required this.revenus, required this.depenses});

  @override
  Widget build(BuildContext context) {
    final mois = ['J','F','M','A','M','J','J','A','S','O','N','D'];
    final maxY = (revenus + depenses).fold(0.0, (a, b) => a > b ? a : b);

    return Card(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(12, 16, 12, 8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Revenus vs Dépenses', style: AppTextStyles.heading3),
          const SizedBox(height: 4),
          Row(children: [
            _Legend(AppColors.secondary, 'Revenus'),
            const SizedBox(width: 16),
            _Legend(AppColors.reparation, 'Dépenses'),
          ]),
          const SizedBox(height: 16),
          SizedBox(
            height: 180,
            child: BarChart(BarChartData(
              maxY: maxY * 1.2,
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                getDrawingHorizontalLine: (_) => FlLine(
                  color: AppColors.border, strokeWidth: 0.5),
              ),
              borderData: FlBorderData(show: false),
              titlesData: FlTitlesData(
                leftTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false)),
                topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false)),
                rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false)),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, _) => Text(
                      mois[v.toInt().clamp(0, 11)],
                      style: AppTextStyles.label),
                  )),
              ),
              barGroups: List.generate(12, (i) => BarChartGroupData(
                x: i,
                barRods: [
                  BarChartRodData(
                    toY: revenus.length > i ? revenus[i] : 0,
                    color: AppColors.secondary,
                    width: 8, borderRadius: BorderRadius.circular(3)),
                  BarChartRodData(
                    toY: depenses.length > i ? depenses[i] : 0,
                    color: AppColors.reparation,
                    width: 8, borderRadius: BorderRadius.circular(3)),
                ],
              )),
            )),
          ),
        ]),
      ),
    );
  }
}

class _Legend extends StatelessWidget {
  final Color color;
  final String label;
  const _Legend(this.color, this.label);
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 10, height: 10,
      decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
    const SizedBox(width: 4),
    Text(label, style: AppTextStyles.label),
  ]);
}

class RepartitionPieChart extends StatelessWidget {
  final Map<String, double> parts; // {role: montant}
  const RepartitionPieChart({super.key, required this.parts});

  @override
  Widget build(BuildContext context) {
    final colors = [AppColors.admin, AppColors.gerant, AppColors.proprietaireShowroom, AppColors.proprietaireVehicule];
    final entries = parts.entries.toList();
    final total   = parts.values.fold(0.0, (a, b) => a + b);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Répartition du mois', style: AppTextStyles.heading3),
          const SizedBox(height: 12),
          Row(children: [
            SizedBox(
              width: 100, height: 100,
              child: PieChart(PieChartData(
                sectionsSpace: 2,
                centerSpaceRadius: 28,
                sections: List.generate(entries.length, (i) => PieChartSectionData(
                  color: colors[i % colors.length],
                  value: entries[i].value,
                  title: '',
                  radius: 28,
                )),
              )),
            ),
            const SizedBox(width: 16),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: List.generate(entries.length, (i) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(children: [
                  Container(width: 10, height: 10,
                    decoration: BoxDecoration(
                      color: colors[i % colors.length],
                      borderRadius: BorderRadius.circular(2))),
                  const SizedBox(width: 6),
                  Expanded(child: Text(entries[i].key,
                    style: AppTextStyles.body)),
                  Text(total > 0
                    ? '${(entries[i].value / total * 100).toStringAsFixed(0)}%'
                    : '0%',
                    style: AppTextStyles.bodySecondary),
                ]),
              )),
            )),
          ]),
        ]),
      ),
    );
  }
}
