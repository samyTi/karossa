import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:cached_network_image/cached_network_image.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';
import '../../../shared/widgets/custom_app_bar.dart';
import '../../../shared/widgets/status_badge.dart';
import '../../../shared/widgets/empty_state.dart';
import '../domain/vehicule_model.dart';
import 'vehicules_provider.dart';

class CatalogueScreen extends ConsumerWidget {
  const CatalogueScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final vehicules = ref.watch(vehiculesFiltresProvider);
    final statut    = ref.watch(statutFiltreProvider);

    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Catalogue',
        showBackButton: false,
        showHomeButton: true,
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => context.push('/vehicules/new'),
        icon: const Icon(Icons.add),
        label: const Text('Nouveau'),
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
      body: Column(children: [
        _StatutFilterBar(selected: statut),
        Expanded(child: vehicules.when(
          loading: () => const Center(child: CircularProgressIndicator()),
          error:   (e, _) => Center(child: Text('Erreur: $e')),
          data:    (list) => list.isEmpty
            ? const EmptyState(icon: Icons.directions_car_outlined,
                message: 'Aucun véhicule dans le stock')
            : ListView.builder(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                itemCount: list.length,
                itemBuilder: (_, i) => _VehiculeCard(
                  vehicule: list[i],
                  onTap: () => context.push('/vehicules/${list[i].id}'),
                ),
              ),
        )),
      ]),
    );
  }
}

class _StatutFilterBar extends ConsumerWidget {
  final VehiculeStatut? selected;
  const _StatutFilterBar({required this.selected});
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statuts = [null, VehiculeStatut.disponible, VehiculeStatut.loue,
                     VehiculeStatut.reparation, VehiculeStatut.reserve];
    return SizedBox(
      height: 52,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        children: statuts.map((s) {
          final isSelected = s == selected;
          final label = s == null ? 'Tous' : s.label;
          final color = s == null ? AppColors.primary : s.color;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(label, style: TextStyle(fontSize: 12,
                fontWeight: FontWeight.w500,
                color: isSelected ? Colors.white : color)),
              selected: isSelected,
              onSelected: (_) =>
                ref.read(statutFiltreProvider.notifier).state = s,
              selectedColor: color,
              backgroundColor: color.withOpacity(0.1),
              side: BorderSide(color: color.withOpacity(0.3)),
              showCheckmark: false,
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _VehiculeCard extends StatelessWidget {
  final Vehicule vehicule;
  final VoidCallback onTap;
  const _VehiculeCard({required this.vehicule, required this.onTap});

  @override
  Widget build(BuildContext context) => Card(
    margin: const EdgeInsets.only(bottom: 10),
    child: InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(width: 80, height: 60,
              child: vehicule.photos.isNotEmpty
                ? CachedNetworkImage(imageUrl: vehicule.photos.first,
                    fit: BoxFit.cover,
                    errorWidget: (_, __, ___) => const _PhotoPlaceholder())
                : const _PhotoPlaceholder()),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Expanded(child: Text(vehicule.displayName,
                  style: AppTextStyles.heading3, maxLines: 1,
                  overflow: TextOverflow.ellipsis)),
                StatusBadge(statut: vehicule.statut),
              ]),
              const SizedBox(height: 4),
              Text('${vehicule.kilometrage} km'
                + (vehicule.immatriculation != null
                   ? ' · ${vehicule.immatriculation}' : ''),
                style: AppTextStyles.bodySecondary),
              const SizedBox(height: 4),
              Wrap(spacing: 6, children: [
                if (vehicule.prixLocationJour != null)
                  _Chip('${vehicule.prixLocationJour!.toInt()} DA/j',
                    AppColors.secondary),
                if (vehicule.prixVente != null)
                  _Chip('${vehicule.prixVente!.toInt()} DA',
                    AppColors.primary),
              ]),
              if (vehicule.proprietes.isNotEmpty) ...[
                const SizedBox(height: 2),
                Text(vehicule.proprietes
                  .map((p) => '${p.proprietaireNom} ${p.partPct.toInt()}%')
                  .join(' · '),
                  style: AppTextStyles.label, maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              ],
            ],
          )),
          const Icon(Icons.chevron_right, color: AppColors.textSecondary),
        ]),
      ),
    ),
  );
}

class _Chip extends StatelessWidget {
  final String label;
  final Color color;
  const _Chip(this.label, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(
      color: color.withOpacity(0.1),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(label,
      style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: color)),
  );
}

class _PhotoPlaceholder extends StatelessWidget {
  const _PhotoPlaceholder();
  @override
  Widget build(BuildContext context) => Container(
    color: AppColors.inputFill,
    child: const Icon(Icons.directions_car, color: AppColors.border, size: 28),
  );
}
