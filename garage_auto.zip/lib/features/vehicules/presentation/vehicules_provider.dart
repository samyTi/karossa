import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../data/vehicules_repository.dart';
import '../domain/vehicule_model.dart';

final vehiculesRepositoryProvider = Provider((_) => VehiculesRepository());

final vehiculesProvider = FutureProvider.autoDispose<List<Vehicule>>((ref) {
  return ref.watch(vehiculesRepositoryProvider).getAll();
});

final vehiculeDetailProvider =
    FutureProvider.autoDispose.family<Vehicule, String>((ref, id) {
  return ref.watch(vehiculesRepositoryProvider).getById(id);
});

final statutFiltreProvider = StateProvider<VehiculeStatut?>((ref) => null);

final vehiculesFiltresProvider =
    Provider.autoDispose<AsyncValue<List<Vehicule>>>((ref) {
  final statut   = ref.watch(statutFiltreProvider);
  final vehicules = ref.watch(vehiculesProvider);
  if (statut == null) return vehicules;
  return vehicules.whenData(
    (list) => list.where((v) => v.statut == statut).toList());
});
