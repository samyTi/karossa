// lib/features/locations/data/locations_repository.dart
// print() DEBUG supprimés.
// montant_brut retiré du payload cloturerLocation()
// (GENERATED ALWAYS AS STORED — Postgres refuse l'écriture).

import '../../../main.dart';
import '../domain/location_model.dart';

class LocationsRepository {
  Future<List<Location>> getActives() async {
    final data = await supabase
      .from('locations')
      .select(
        '*, vehicules(marque, modele),'
        'clients(prenom, nom, telephone),'
        'location_repartitions(*, profiles(prenom))'
      )
      .inFilter('statut', ['en_cours', 'retard'])
      .order('date_fin_prevue');
    return data.map((j) => Location.fromJson(j)).toList();
  }

  Future<List<Location>> getRetards() async {
    final now = DateTime.now().toIso8601String();
    final data = await supabase
      .from('locations')
      .select('*, vehicules(marque, modele), clients(prenom, nom, telephone)')
      .eq('statut', 'en_cours')
      .lt('date_fin_prevue', now);
    return data.map((j) => Location.fromJson(j)).toList();
  }

  Future<Location?> getById(String id) async {
    try {
      final data = await supabase
        .from('locations')
        .select(
          '*, vehicules(marque, modele),'
          'clients(prenom, nom, telephone),'
          'location_repartitions(*, profiles(prenom)),'
          'location_paiements(id, montant, date_paiement, mode)'
        )
        .eq('id', id)
        .single();
      return Location.fromJson(data);
    } catch (_) { return null; }
  }

  Future<Location> create(Map<String, dynamic> locationData) async {
    // Ne jamais envoyer les colonnes GENERATED ALWAYS AS STORED
    locationData.remove('nb_jours');
    locationData.remove('montant_brut');
    final response = await supabase
      .from('locations').insert(locationData).select();
    if (response is! List || response.isEmpty) {
      throw Exception('Erreur création location : réponse inattendue');
    }
    return Location.fromJson(response.first);
  }

  Future<void> cloturerLocation({
    required String locationId,
    required int kmRetour,
    required double retenueCaution,
    String? notesRetour,
  }) async {
    // montant_brut est GENERATED — Postgres le recalcule automatiquement.
    await supabase.from('locations').update({
      'statut':          'termine',
      'date_fin_reelle': DateTime.now().toIso8601String(),
      'km_retour':       kmRetour,
      'retenue_caution': retenueCaution,
      'notes_retour':    notesRetour,
    }).eq('id', locationId);
    await supabase.rpc('calculer_repartition_location',
      params: {'p_location_id': locationId});
  }

  Future<List<LocationPaiement>> getPaiements(String locationId) async {
    try {
      final data = await supabase
          .from('location_paiements').select()
          .eq('location_id', locationId)
          .order('date_paiement', ascending: false);
      return (data as List).map((j) => LocationPaiement.fromJson(j)).toList();
    } catch (_) { return []; }
  }

  Future<LocationPaiement?> addPaiement(LocationPaiement p) async {
    try {
      final data = await supabase
          .from('location_paiements').insert(p.toJson()).select().single();
      return LocationPaiement.fromJson(data);
    } catch (_) { return null; }
  }
}
