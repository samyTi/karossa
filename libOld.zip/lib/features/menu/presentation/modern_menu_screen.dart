import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';
import '../../../core/constants/app_spacing.dart';
import '../../auth/presentation/auth_provider.dart';

class ModernMenuScreen extends ConsumerStatefulWidget {
  const ModernMenuScreen({super.key});

  @override
  ConsumerState<ModernMenuScreen> createState() => _ModernMenuScreenState();
}

class _ModernMenuScreenState extends ConsumerState<ModernMenuScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  String _searchQuery = '';

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    );
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  // Données du menu organisées par catégories
  final List<MenuCategory> _categories = [
    MenuCategory(
      title: 'Fréquent',
      icon: Icons.star,
      color: AppColors.accent,
      items: [
        MenuItem(
          label: 'Ventes',
          icon: Icons.sell,
          color: AppColors.secondary,
          route: '/ventes',
          badge: 3,
        ),
        MenuItem(
          label: 'Caisse',
          icon: Icons.account_balance_wallet,
          color: AppColors.primary,
          route: '/caisse',
        ),
        MenuItem(
          label: 'Assistant IA',
          icon: Icons.auto_awesome,
          color: AppColors.accent,
          route: '/ai-chat',
        ),
      ],
    ),
    MenuCategory(
      title: 'Transactions',
      icon: Icons.swap_horiz,
      color: AppColors.secondary,
      items: [
        MenuItem(
          label: 'Ventes',
          icon: Icons.sell,
          color: AppColors.secondary,
          route: '/ventes',
        ),
        MenuItem(
          label: 'Achats',
          icon: Icons.shopping_cart,
          color: AppColors.accent,
          route: '/achats',
        ),
        MenuItem(
          label: 'Échanges',
          icon: Icons.swap_horiz,
          color: AppColors.primary,
          route: '/echanges',
        ),
      ],
    ),
    MenuCategory(
      title: 'Opérations',
      icon: Icons.build,
      color: AppColors.primary,
      items: [
        MenuItem(
          label: 'Caisse',
          icon: Icons.account_balance_wallet,
          color: AppColors.primary,
          route: '/caisse',
        ),
        MenuItem(
          label: 'Réparations',
          icon: Icons.build,
          color: AppColors.reparation,
          route: '/reparations',
        ),
        MenuItem(
          label: 'Entretien',
          icon: Icons.calendar_today,
          color: AppColors.accent,
          route: '/entretien',
        ),
        MenuItem(
          label: 'Relevé',
          icon: Icons.bar_chart,
          color: AppColors.loue,
          route: '/releve',
        ),
      ],
    ),
    MenuCategory(
      title: 'GPS & Suivi',
      icon: Icons.location_on,
      color: AppColors.loue,
      items: [
        MenuItem(
          label: 'Carte Live',
          icon: Icons.map,
          color: AppColors.secondary,
          route: '/gps',
        ),
        MenuItem(
          label: 'Alertes GPS',
          icon: Icons.notifications,
          color: AppColors.retard,
          route: '/gps/alertes',
        ),
      ],
    ),
    MenuCategory(
      title: 'Administration',
      icon: Icons.settings,
      color: AppColors.textSecondary,
      items: [
        MenuItem(
          label: 'Utilisateurs',
          icon: Icons.manage_accounts,
          color: AppColors.primary,
          route: '/admin/users',
        ),
        MenuItem(
          label: 'Paramètres',
          icon: Icons.settings,
          color: AppColors.textSecondary,
          route: '/admin/settings',
        ),
        MenuItem(
          label: 'Contrats',
          icon: Icons.description,
          color: AppColors.accent,
          route: '/contrats',
        ),
        MenuItem(
          label: 'Mon profil',
          icon: Icons.person,
          color: AppColors.primary,
          route: '/profil',
        ),
      ],
    ),
  ];

  List<MenuItem> get _filteredItems {
    if (_searchQuery.isEmpty) return [];
    final query = _searchQuery.toLowerCase();
    return _categories
        .expand((cat) => cat.items)
        .where((item) => item.label.toLowerCase().contains(query))
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final profile = ref.watch(currentProfileProvider).valueOrNull;
    final prenom = profile?.prenom ?? '';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: CustomScrollView(
          slivers: [
            // Header moderne avec dégradé
            _buildModernHeader(prenom),

            // Barre de recherche
            _buildSearchBar(),

            // Résultats de recherche
            if (_searchQuery.isNotEmpty) _buildSearchResults(),

            // Catégories du menu
            ..._buildCategorySlivers(),

            // Padding final
            const SliverToBoxAdapter(
              child: SizedBox(height: 40),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildModernHeader(String prenom) {
    return SliverAppBar(
      expandedHeight: 140,
      floating: false,
      pinned: true,
      elevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppColors.primary,
                AppColors.primary.withValues(alpha: 0.9),
                AppColors.secondary.withValues(alpha: 0.7),
              ],
            ),
          ),
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          color: Colors.white.withValues(alpha: 0.25),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: Colors.white.withValues(alpha: 0.4),
                            width: 1.5,
                          ),
                        ),
                        child: const Icon(
                          Icons.menu_rounded,
                          color: Colors.white,
                          size: 26,
                        ),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Bonjour, $prenom',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const Text(
                              'Que voulez-vous faire ?',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchBar() {
    return SliverToBoxAdapter(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: AppColors.border),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: TextField(
            onChanged: (value) => setState(() => _searchQuery = value),
            decoration: InputDecoration(
              hintText: 'Rechercher une fonction...',
              hintStyle: TextStyle(color: AppColors.textHint, fontSize: 14),
              prefixIcon: const Icon(Icons.search, color: AppColors.textSecondary),
              suffixIcon: _searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear, color: AppColors.textSecondary),
                      onPressed: () => setState(() => _searchQuery = ''),
                    )
                  : null,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(
                horizontal: AppSpacing.md,
                vertical: AppSpacing.sm,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSearchResults() {
    final items = _filteredItems;
    if (items.isEmpty) {
      return SliverToBoxAdapter(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            children: [
              Icon(Icons.search_off, size: 48, color: AppColors.textHint),
              const SizedBox(height: 12),
              Text(
                'Aucun résultat trouvé',
                style: AppTextStyles.bodySecondary,
              ),
            ],
          ),
        ),
      );
    }

    return SliverToBoxAdapter(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text(
              '${items.length} résultat(s)',
              style: AppTextStyles.heading3.copyWith(color: AppColors.textSecondary),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: GridView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.5,
              ),
              itemCount: items.length,
              itemBuilder: (context, index) => _buildMenuItem(items[index]),
            ),
          ),
          const SizedBox(height: 16),
          const Divider(height: 1),
        ],
      ),
    );
  }

  List<Widget> _buildCategorySlivers() {
    return _categories.asMap().entries.map((entry) {
      final index = entry.key;
      final category = entry.value;
      return SliverToBoxAdapter(
        child: _buildCategorySection(category, index),
      );
    }).toList();
  }

  Widget _buildCategorySection(MenuCategory category, int index) {
    return Padding(
      padding: const EdgeInsets.only(top: 20, left: 16, right: 16, bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  color: category.color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Icon(
                  category.icon,
                  size: 16,
                  color: category.color,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                category.title,
                style: AppTextStyles.heading3.copyWith(
                  color: AppColors.textPrimary,
                ),
              ),
              const Spacer(),
              Text(
                '${category.items.length}',
                style: AppTextStyles.label.copyWith(
                  color: category.color,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 12,
              mainAxisSpacing: 12,
              childAspectRatio: 1.5,
            ),
            itemCount: category.items.length,
            itemBuilder: (context, i) => _buildMenuItem(category.items[i]),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuItem(MenuItem item) {
    return InkWell(
      onTap: () {
        HapticFeedback.lightImpact();
        context.go(item.route);
      },
      borderRadius: BorderRadius.circular(16),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: item.color.withValues(alpha: 0.15)),
          boxShadow: [
            BoxShadow(
              color: item.color.withValues(alpha: 0.06),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: item.color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(item.icon, size: 24, color: item.color),
                ),
                const SizedBox(height: 8),
                Text(
                  item.label,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: item.color,
                  ),
                  textAlign: TextAlign.center,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
            if (item.badge != null)
              Positioned(
                right: 8,
                top: 8,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.retard,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${item.badge}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// Modèles de données pour le menu
class MenuCategory {
  final String title;
  final IconData icon;
  final Color color;
  final List<MenuItem> items;

  MenuCategory({
    required this.title,
    required this.icon,
    required this.color,
    required this.items,
  });
}

class MenuItem {
  final String label;
  final IconData icon;
  final Color color;
  final String route;
  final int? badge;

  MenuItem({
    required this.label,
    required this.icon,
    required this.color,
    required this.route,
    this.badge,
  });
}