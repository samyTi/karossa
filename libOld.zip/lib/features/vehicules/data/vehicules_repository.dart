import '../../../main.dart';
import '../domain/vehicule_model.dart';

class VehiculesRepository {
  Future<List<Vehicule>> getAll({VehiculeStatut? statut}) async {
    var query = supabase
      .from('vehicules')
      .select('*, vehicule_proprietes(*, profiles(prenom, nom))');

    if (statut != null) {
      final data = await query.eq('statut', statut.name)
        .order('created_at', ascending: false);
      return data.map((j) => Vehicule.fromJson(j)).toList();
    }
    final data = await query.neq('statut', 'vendu')
      .order('created_at', ascending: false);
    return data.map((j) => Vehicule.fromJson(j)).toList();
  }

  Future<Vehicule> getById(String id) async {
    final data = await supabase
      .from('vehicules')
      .select('*, vehicule_proprietes(*, profiles(prenom, nom))')
      .eq('id', id)
      .single();
    return Vehicule.fromJson(data);
  }

  Future<Vehicule> create(
    Map<String, dynamic> vehiculeData,
    List<Map<String, dynamic>> proprietes,
  ) async {
    final result = await supabase
      .from('vehicules')
      .insert(vehiculeData)
      .select()
      .single();
    for (final prop in proprietes) {
      await supabase.from('vehicule_proprietes')
        .insert({'vehicule_id': result['id'], ...prop});
    }
    return getById(result['id']);
  }

  Future<void> update(String id, Map<String, dynamic> data) async {
    await supabase.from('vehicules').update(data).eq('id', id);
  }

  /// Calcule automatiquement la marge et met à jour dans Supabase
  ///
  /// Appeler après une vente pour stocker le prix de revient final.
  Future<Map<String, double>> calculateAndSaveMargin({
    required String vehiculeId,
    required double prixVente,
  }) async {
    // Agrège les dépenses directement
    final futureVehicule = supabase.from('vehicules').select('prix_achat').eq('id', vehiculeId).single();
    final futureReparations = supabase.from('reparations').select('cout').eq('vehicule_id', vehiculeId).eq('deductible', true);
    final futureCaisseOps = supabase.from('caisse_operations').select('montant, categorie').eq('vehicule_id', vehiculeId).eq('type', 'sortie');

    final List<dynamic> results = await Future.wait<dynamic>([
      futureVehicule,
      futureReparations,
      futureCaisseOps,
    ]);

    final vehiculeData = results[0] as Map<String, dynamic>;
    final reparations  = results[1] as List;
    final caisseOps    = results[2] as List;

    final prixAchat = (vehiculeData['prix_achat'] as num?)?.toDouble() ?? 0.0;
    final totalRep  = reparations.fold(0.0, (s, r) => s + (r['cout'] as num).toDouble());

    const fraisCats = ['entretien', 'carburant', 'lavage', 'assurance', 'controle_technique'];
    final totalFrais = caisseOps
        .where((op) => fraisCats.contains(op['categorie']))
        .fold(0.0, (s, op) => s + (op['montant'] as num).toDouble());

    final prixRevient = prixAchat + totalRep + totalFrais;
    final marge       = prixVente - prixRevient;
    final margePct    = prixRevient > 0 ? (marge / prixRevient) * 100 : 0.0;

    return {
      'prixRevient': prixRevient,
      'marge':       marge,
      'margePct':    margePct,
    };
  }
}
