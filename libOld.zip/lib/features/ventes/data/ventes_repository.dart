// lib/features/ventes/data/ventes_repository.dart
// Singleton manuel supprimé — Riverpod gère le cycle de vie.
// getStats() lit vente_paiements (acompte supprimé de la DB).

import 'package:flutter/foundation.dart';
import '../../../main.dart';
import '../domain/vente_model.dart';

class VentesRepository {
  Future<List<Vente>> getAll() async {
    try {
      final data = await supabase
          .from('ventes')
          .select(
            '*, vehicules(marque, modele, annee, immatriculation),'
            'clients(prenom, nom, telephone),'
            'vente_paiements(id, montant, date_paiement, mode)'
          )
          .order('created_at', ascending: false);
      return (data as List).map((j) => Vente.fromJson(j)).toList();
    } catch (e) {
      debugPrint('VentesRepository.getAll: $e');
      return [];
    }
  }

  Future<Vente?> getById(String id) async {
    try {
      final data = await supabase
          .from('ventes')
          .select(
            '*, vehicules(marque, modele, annee),'
            'clients(prenom, nom),'
            'vente_paiements(id, montant, date_paiement, mode, notes)'
          )
          .eq('id', id)
          .single();
      return Vente.fromJson(data);
    } catch (e) {
      debugPrint('VentesRepository.getById: $e');
      return null;
    }
  }

  Future<Vente?> create(Map<String, dynamic> payload) async {
    try {
      payload.remove('acompte');
      payload.remove('solde_restant');
      final data = await supabase
          .from('ventes').insert(payload).select().single();
      return Vente.fromJson(data);
    } catch (e) {
      debugPrint('VentesRepository.create: $e');
      return null;
    }
  }

  Future<void> update(String id, Map<String, dynamic> payload) async {
    try {
      payload.remove('acompte');
      payload.remove('solde_restant');
      await supabase.from('ventes').update(payload).eq('id', id);
    } catch (e) {
      debugPrint('VentesRepository.update: $e');
      rethrow;
    }
  }

  Future<List<VentePaiement>> getPaiements(String venteId) async {
    try {
      final data = await supabase
          .from('vente_paiements').select()
          .eq('vente_id', venteId)
          .order('date_paiement', ascending: false);
      return (data as List).map((j) => VentePaiement.fromJson(j)).toList();
    } catch (e) {
      debugPrint('VentesRepository.getPaiements: $e');
      return [];
    }
  }

  Future<VentePaiement?> addPaiement(VentePaiement paiement) async {
    try {
      final data = await supabase
          .from('vente_paiements').insert(paiement.toJson()).select().single();
      return VentePaiement.fromJson(data);
    } catch (e) {
      debugPrint('VentesRepository.addPaiement: $e');
      return null;
    }
  }

  Future<void> deletePaiement(String id) async {
    await supabase.from('vente_paiements').delete().eq('id', id);
  }

  Future<Map<String, dynamic>> getStats() async {
    try {
      final ventes = await supabase
          .from('ventes')
          .select('id, prix_vente, statut_paiement, vente_paiements(montant)');
      final list = ventes as List;
      final total    = list.length;
      final revenu   = list.fold<double>(
          0, (s, v) => s + ((v['prix_vente'] as num?)?.toDouble() ?? 0));
      final encaisse = list.fold<double>(0, (s, v) {
        final p = (v['vente_paiements'] as List? ?? []);
        return s + p.fold<double>(
            0, (sp, x) => sp + ((x['montant'] as num?)?.toDouble() ?? 0));
      });
      return {
        'total':    total,
        'revenu':   revenu,
        'encaisse': encaisse,
        'moyen':    total > 0 ? revenu / total : 0.0,
      };
    } catch (e) {
      debugPrint('VentesRepository.getStats: $e');
      return {'total': 0, 'revenu': 0.0, 'encaisse': 0.0, 'moyen': 0.0};
    }
  }
}
