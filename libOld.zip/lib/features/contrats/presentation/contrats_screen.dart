// lib/features/contrats/presentation/contrats_screen.dart
// Page professionnelle de gestion des contrats (locations, ventes, échanges)
// Affiche TOUTES les opérations et permet de générer les contrats PDF à la demande

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:share_plus/share_plus.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import '../../../core/constants/app_colors.dart';
import '../../../core/constants/app_text_styles.dart';
import '../../../shared/widgets/custom_app_bar.dart';
import '../../../shared/widgets/empty_state.dart';
import '../../../shared/services/notification_service.dart';
import '../../../main.dart';
import '../../../core/services/contrat_generator_service.dart';
// ✅ Les modèles domain ne sont plus nécessaires ici :
// contrat_generator_service.dart travaille directement avec les Map<String,dynamic>.
import '../data/contrats_repository.dart';

// Provider pour charger toutes les opérations (locations + ventes + échanges)
final allContratsProvider = FutureProvider<ContratHistory>((ref) async {
  final now = DateTime.now();
  final oneYearAgo = DateTime(now.year - 1, now.month, now.day);
  
  // Charger TOUTES les locations (avec ou sans PDF)
  final locationsData = await supabase
      .from('locations')
      .select('*, clients(nom, prenom, telephone), vehicules(marque, modele)')
      .gte('date_debut', oneYearAgo.toIso8601String())
      .order('date_debut', ascending: false);
  
  // Charger TOUTES les ventes (avec ou sans PDF)
  final ventesData = await supabase
      .from('ventes')
      .select('*, clients(nom, prenom, telephone), vehicules(marque, modele)')
      .gte('date_vente', oneYearAgo.toIso8601String())
      .order('date_vente', ascending: false);
  
  // Charger TOUS les échanges (avec ou sans PDF)
  final echangesData = await supabase
      .from('echanges')
      .select('*, clients(nom, prenom, telephone), vehicules!echanges_vehicule_cede_id_fkey(marque, modele)')
      .gte('date_echange', oneYearAgo.toIso8601String())
      .order('date_echange', ascending: false);
  
  return ContratHistory(
    locations: locationsData.map((l) => LocationWithDetails.fromJson(l)).toList(),
    ventes: ventesData.map((v) => VenteWithDetails.fromJson(v)).toList(),
    echanges: echangesData.map((e) => EchangeWithDetails.fromJson(e)).toList(),
  );
});

class ContratHistory {
  final List<LocationWithDetails> locations;
  final List<VenteWithDetails> ventes;
  final List<EchangeWithDetails> echanges;
  
  ContratHistory({
    required this.locations,
    required this.ventes,
    required this.echanges,
  });
  
  List<ContratItem> get allContrats {
    final items = <ContratItem>[];
    
    for (final loc in locations) {
      items.add(ContratItem(
        id: loc.id,
        type: 'location',
        clientNom: '${loc.client?.prenom ?? ''} ${loc.client?.nom ?? ''}'.trim(),
        clientTel: loc.client?.telephone ?? '',
        vehiculeNom: '${loc.vehicule?.marque ?? ''} ${loc.vehicule?.modele ?? ''}'.trim(),
        dateContrat: DateTime.tryParse(loc.dateDebut) ?? DateTime.now(),
        pdfUrl: loc.contratPdfUrl,
        montant: loc.prixLocationJour * (loc.nbJours ?? 1),
      ));
    }
    
    for (final vente in ventes) {
      items.add(ContratItem(
        id: vente.id,
        type: 'vente',
        clientNom: '${vente.client?.prenom ?? ''} ${vente.client?.nom ?? ''}'.trim(),
        clientTel: vente.client?.telephone ?? '',
        vehiculeNom: '${vente.vehicule?.marque ?? ''} ${vente.vehicule?.modele ?? ''}'.trim(),
        dateContrat: DateTime.tryParse(vente.dateVente) ?? DateTime.now(),
        pdfUrl: vente.contratPdfUrl,
        montant: vente.prixVente,
      ));
    }
    
    for (final echange in echanges) {
      items.add(ContratItem(
        id: echange.id,
        type: 'echange',
        clientNom: '${echange.client?.prenom ?? ''} ${echange.client?.nom ?? ''}'.trim(),
        clientTel: echange.client?.telephone ?? '',
        vehiculeNom: '${echange.vehicule?.marque ?? ''} ${echange.vehicule?.modele ?? ''}'.trim(),
        dateContrat: DateTime.tryParse(echange.dateEchange) ?? DateTime.now(),
        pdfUrl: echange.contratPdfUrl,
        montant: echange.valeurReprise + echange.complementClient,
      ));
    }
    
    items.sort((a, b) => b.dateContrat.compareTo(a.dateContrat));
    return items;
  }
}

class ContratItem {
  final String id;
  final String type;
  final String clientNom;
  final String clientTel;
  final String vehiculeNom;
  final DateTime dateContrat;
  final String? pdfUrl;
  final double montant;
  
  ContratItem({
    required this.id,
    required this.type,
    required this.clientNom,
    required this.clientTel,
    required this.vehiculeNom,
    required this.dateContrat,
    this.pdfUrl,
    required this.montant,
  });
  
  String get typeLabel {
    switch (type) {
      case 'location': return 'Location';
      case 'vente': return 'Vente';
      case 'echange': return 'Échange';
      default: return 'Contrat';
    }
  }
  
  bool get hasContract => pdfUrl != null && pdfUrl!.isNotEmpty;
  
  (IconData, Color) get typeInfo {
    switch (type) {
      case 'location': return (Icons.car_rental, AppColors.primary);
      case 'vente': return (Icons.sell, AppColors.secondary);
      case 'echange': return (Icons.swap_horiz, AppColors.accent);
      default: return (Icons.description, AppColors.textSecondary);
    }
  }
}

// Modèles de données pour les jointures
class LocationWithDetails {
  final String id;
  final String dateDebut;
  final double prixLocationJour;
  final int? nbJours;
  final String? contratPdfUrl;
  final ClientSimple? client;
  final VehiculeSimple? vehicule;
  
  LocationWithDetails({
    required this.id,
    required this.dateDebut,
    required this.prixLocationJour,
    this.nbJours,
    this.contratPdfUrl,
    this.client,
    this.vehicule,
  });
  
  factory LocationWithDetails.fromJson(Map<String, dynamic> json) {
    return LocationWithDetails(
      id: json['id'] ?? '',
      dateDebut: json['date_debut'] ?? '',
      prixLocationJour: (json['prix_jour'] as num?)?.toDouble() ?? 0,  // ✅ FIX : champ DB = prix_jour (pas prix_location_jour)
      nbJours: json['nb_jours'],
      contratPdfUrl: json['contrat_pdf_url'],
      client: json['clients'] != null ? ClientSimple.fromJson(json['clients']) : null,
      vehicule: json['vehicules'] != null ? VehiculeSimple.fromJson(json['vehicules']) : null,
    );
  }
}

class VenteWithDetails {
  final String id;
  final String dateVente;
  final double prixVente;
  final String? contratPdfUrl;
  final ClientSimple? client;
  final VehiculeSimple? vehicule;
  
  VenteWithDetails({
    required this.id,
    required this.dateVente,
    required this.prixVente,
    this.contratPdfUrl,
    this.client,
    this.vehicule,
  });
  
  factory VenteWithDetails.fromJson(Map<String, dynamic> json) {
    return VenteWithDetails(
      id: json['id'] ?? '',
      dateVente: json['date_vente'] ?? '',
      prixVente: (json['prix_vente'] as num?)?.toDouble() ?? 0,
      contratPdfUrl: json['contrat_pdf_url'],
      client: json['clients'] != null ? ClientSimple.fromJson(json['clients']) : null,
      vehicule: json['vehicules'] != null ? VehiculeSimple.fromJson(json['vehicules']) : null,
    );
  }
}

class EchangeWithDetails {
  final String id;
  final String dateEchange;
  final double valeurReprise;
  final double complementClient;
  final String? contratPdfUrl;
  final ClientSimple? client;
  final VehiculeSimple? vehicule;
  
  EchangeWithDetails({
    required this.id,
    required this.dateEchange,
    required this.valeurReprise,
    required this.complementClient,
    this.contratPdfUrl,
    this.client,
    this.vehicule,
  });
  
  factory EchangeWithDetails.fromJson(Map<String, dynamic> json) {
    return EchangeWithDetails(
      id: json['id'] ?? '',
      dateEchange: json['date_echange'] ?? '',
      valeurReprise: (json['valeur_reprise'] as num?)?.toDouble() ?? 0,
      complementClient: (json['complement_client'] as num?)?.toDouble() ?? 0,
      contratPdfUrl: json['contrat_pdf_url'],
      client: json['clients'] != null ? ClientSimple.fromJson(json['clients']) : null,
      vehicule: json['vehicules'] != null ? VehiculeSimple.fromJson(json['vehicules']) : null,
    );
  }
}

class ClientSimple {
  final String nom;
  final String prenom;
  final String telephone;
  
  ClientSimple({required this.nom, required this.prenom, required this.telephone});
  
  factory ClientSimple.fromJson(Map<String, dynamic> json) {
    return ClientSimple(
      nom: json['nom'] ?? '',
      prenom: json['prenom'] ?? '',
      telephone: json['telephone'] ?? '',
    );
  }
}

class VehiculeSimple {
  final String marque;
  final String modele;
  
  VehiculeSimple({required this.marque, required this.modele});
  
  factory VehiculeSimple.fromJson(Map<String, dynamic> json) {
    return VehiculeSimple(
      marque: json['marque'] ?? '',
      modele: json['modele'] ?? '',
    );
  }
}

class ContratsScreen extends ConsumerStatefulWidget {
  const ContratsScreen({super.key});

  @override
  ConsumerState<ContratsScreen> createState() => _ContratsScreenState();
}

class _ContratsScreenState extends ConsumerState<ContratsScreen> {
  String _filterType = 'all'; // 'all', 'location', 'vente', 'echange'
  bool _showOnlyWithoutContract = false;

  @override
  Widget build(BuildContext context) {
    final contratsAsync = ref.watch(allContratsProvider);

    return Scaffold(
      appBar: const CustomAppBar(
        title: 'Gestion des contrats',
        showBackButton: true,
        showHomeButton: true,
      ),
      body: contratsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('Erreur : $e')),
        data: (history) {
          final allContrats = history.allContrats;
          
          // Filtrer par type
          final filteredByType = _filterType == 'all' 
              ? allContrats 
              : allContrats.where((c) => c.type == _filterType).toList();
          
          // Filtrer par statut de contrat
          final contrats = _showOnlyWithoutContract
              ? filteredByType.where((c) => !c.hasContract).toList()
              : filteredByType;
          
          // Calculer les statistiques
          final totalContrats = allContrats.length;
          final totalLocations = allContrats.where((c) => c.type == 'location').length;
          final totalVentes = allContrats.where((c) => c.type == 'vente').length;
          final totalEchanges = allContrats.where((c) => c.type == 'echange').length;
          final withoutContract = allContrats.where((c) => !c.hasContract).length;
          
          return Column(
            children: [
              // Statistiques
              _StatsRow(
                total: totalContrats,
                locations: totalLocations,
                ventes: totalVentes,
                echanges: totalEchanges,
                withoutContract: withoutContract,
              ),
              
              // Filtres
              _FilterBar(
                filterType: _filterType,
                showOnlyWithoutContract: _showOnlyWithoutContract,
                onFilterTypeChanged: (type) => setState(() => _filterType = type),
                onShowOnlyWithoutContractChanged: (value) => setState(() => _showOnlyWithoutContract = value),
              ),
              
              // Liste des contrats
              Expanded(
                child: contrats.isEmpty
                    ? const EmptyState(
                        icon: Icons.description_outlined,
                        message: 'Aucune opération trouvée',
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: contrats.length,
                        itemBuilder: (_, i) => _ContratCard(
                          contrat: contrats[i],
                        ),
                      ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _StatsRow extends StatelessWidget {
  final int total;
  final int locations;
  final int ventes;
  final int echanges;
  final int withoutContract;
  
  const _StatsRow({
    required this.total,
    required this.locations,
    required this.ventes,
    required this.echanges,
    required this.withoutContract,
  });
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: const BorderRadius.vertical(bottom: Radius.circular(16)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              _StatChip(label: 'Total', value: total, color: AppColors.primary),
              const SizedBox(width: 8),
              _StatChip(label: 'Locations', value: locations, color: AppColors.primary),
              const SizedBox(width: 8),
              _StatChip(label: 'Ventes', value: ventes, color: AppColors.secondary),
              const SizedBox(width: 8),
              _StatChip(label: 'Échanges', value: echanges, color: AppColors.accent),
            ],
          ),
          if (withoutContract > 0) ...[
            const SizedBox(height: 8),
            _StatChip(
              label: 'Sans contrat', 
              value: withoutContract, 
              color: Colors.orange,
            ),
          ],
        ],
      ),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String label;
  final int value;
  final Color color;
  
  const _StatChip({required this.label, required this.value, required this.color});
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withValues(alpha: 0.3)),
      ),
      child: Column(
        children: [
          Text(
            value.toString(),
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
          Text(
            label,
            style: TextStyle(
              fontSize: 10,
              color: color.withValues(alpha: 0.7),
            ),
          ),
        ],
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  final String filterType;
  final bool showOnlyWithoutContract;
  final Function(String) onFilterTypeChanged;
  final Function(bool) onShowOnlyWithoutContractChanged;
  
  const _FilterBar({
    required this.filterType,
    required this.showOnlyWithoutContract,
    required this.onFilterTypeChanged,
    required this.onShowOnlyWithoutContractChanged,
  });
  
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Column(
        children: [
          // Filtres par type
          Row(
            children: [
              _FilterChip(
                label: 'Tous',
                isSelected: filterType == 'all',
                onTap: () => onFilterTypeChanged('all'),
              ),
              const SizedBox(width: 8),
              _FilterChip(
                label: 'Locations',
                isSelected: filterType == 'location',
                onTap: () => onFilterTypeChanged('location'),
              ),
              const SizedBox(width: 8),
              _FilterChip(
                label: 'Ventes',
                isSelected: filterType == 'vente',
                onTap: () => onFilterTypeChanged('vente'),
              ),
              const SizedBox(width: 8),
              _FilterChip(
                label: 'Échanges',
                isSelected: filterType == 'echange',
                onTap: () => onFilterTypeChanged('echange'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Filtre "sans contrat uniquement"
          Row(
            children: [
              Icon(Icons.warning_amber_rounded, size: 16, color: Colors.orange),
              const SizedBox(width: 4),
              const Text(
                'Afficher uniquement sans contrat',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary),
              ),
              const SizedBox(width: 8),
              Switch(
                value: showOnlyWithoutContract,
                onChanged: onShowOnlyWithoutContractChanged,
                activeThumbColor: Colors.orange,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;
  
  const _FilterChip({
    required this.label,
    required this.isSelected,
    required this.onTap,
  });
  
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.primary : AppColors.background,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppColors.primary : AppColors.border,
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 11,
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
            color: isSelected ? Colors.white : AppColors.textSecondary,
          ),
        ),
      ),
    );
  }
}

class _ContratCard extends StatefulWidget {
  final ContratItem contrat;
  
  const _ContratCard({required this.contrat});
  
  @override
  State<_ContratCard> createState() => _ContratCardState();
}

class _ContratCardState extends State<_ContratCard> {
  bool _isGenerating = false;
  
  Future<void> _generateAndDownloadPdf() async {
    if (_isGenerating) return;
    
    setState(() => _isGenerating = true);
    
    try {
      if (!mounted) return;
      
      Map<String, dynamic>? data;
      
      switch (widget.contrat.type) {
        case 'location':
          data = await _fetchLocationData();
          if (data != null) {
            final file = await _generateLocationPdf(data);
            if (file != null && mounted) {
              // Sauvegarder dans Supabase Storage et lier le contrat
              await _saveAndLinkContract(data['id'], file);
              await _sharePdf(file);
            }
          }
          break;
          
        case 'vente':
          data = await _fetchVenteData();
          if (data != null) {
            final file = await _generateVentePdf(data);
            if (file != null && mounted) {
              // Sauvegarder dans Supabase Storage et lier le contrat
              await _saveAndLinkContract(data['id'], file);
              await _sharePdf(file);
            }
          }
          break;
          
        case 'echange':
          data = await _fetchEchangeData();
          if (data != null) {
            final file = await _generateEchangePdf(data);
            if (file != null && mounted) {
              // Sauvegarder dans Supabase Storage et lier le contrat
              await _saveAndLinkContract(data['id'], file);
              await _sharePdf(file);
            }
          }
          break;
      }
    } catch (e) {
      if (mounted) {
        NotificationService().error('Erreur lors de la génération: ${e.toString()}');
      }
    } finally {
      if (mounted) {
        setState(() => _isGenerating = false);
      }
    }
  }
  
  Future<Map<String, dynamic>?> _fetchLocationData() async {
    try {
      final response = await supabase
          .from('locations')
          .select('*, clients(*), vehicules(*)')
          .eq('id', widget.contrat.id)
          .single();
      return response;
    } catch (e) {
      throw Exception('Impossible de récupérer les données de la location: ${e.toString()}');
    }
  }
  
  Future<Map<String, dynamic>?> _fetchVenteData() async {
    try {
      final response = await supabase
          .from('ventes')
          .select('*, clients(*), vehicules(*)')
          .eq('id', widget.contrat.id)
          .single();
      return response;
    } catch (e) {
      throw Exception('Impossible de récupérer les données de la vente: ${e.toString()}');
    }
  }
  
  Future<Map<String, dynamic>?> _fetchEchangeData() async {
    try {
      final response = await supabase
          .from('echanges')
          .select('*, clients(*), vehicules!echanges_vehicule_cede_id_fkey(*)')
          .eq('id', widget.contrat.id)
          .single();
      return response;
    } catch (e) {
      throw Exception('Impossible de récupérer les données de l\'échange: ${e.toString()}');
    }
  }
  
  Future<File?> _generateLocationPdf(Map<String, dynamic> data) async {
    try {
      // ✅ On passe la Map directement — plus besoin de Location/Client/Vehicule.fromJson
      return await ContratGeneratorService.genererLocation(locationData: data);
    } catch (e) {
      throw Exception('Erreur génération PDF location: ${e.toString()}');
    }
  }
  
  Future<File?> _generateVentePdf(Map<String, dynamic> data) async {
    try {
      return await ContratGeneratorService.genererVenteFromMap(venteData: data);
    } catch (e) {
      throw Exception('Erreur génération PDF vente: ${e.toString()}');
    }
  }
  
  Future<File?> _generateEchangePdf(Map<String, dynamic> data) async {
    try {
      return await ContratGeneratorService.genererEchangeFromMap(echangeData: data);
    } catch (e) {
      throw Exception('Erreur génération PDF échange: ${e.toString()}');
    }
  }
  
  /// Sauvegarde le PDF dans Supabase Storage et met à jour l'URL dans la base de données
  // ✅ FIX : plus de catch silencieux + bonne table pour les échanges
  Future<void> _saveAndLinkContract(String id, File pdfFile) async {
    final repository = ContratsRepository();

    // Déterminer le dossier selon le type
    final String folder;
    switch (widget.contrat.type) {
      case 'location':
        folder = 'locations';
        break;
      case 'vente':
        folder = 'ventes';
        break;
      case 'echange':
        folder = 'echanges';
        break;
      default:
        folder = 'contrats';
    }

    final bytes    = await pdfFile.readAsBytes();
    final fileName = 'contrat_${widget.contrat.type}_${id}_'
                     '${DateTime.now().millisecondsSinceEpoch}.pdf';

    // ✅ FIX a) savePdfToStorage remonte les exceptions → erreur visible dans l'UI
    final pdfUrl = await repository.savePdfToStorage(
      fileName: fileName,
      pdfBytes: bytes,
      folder:   folder,
    );

    if (pdfUrl == null || !mounted) return;

    // ✅ FIX b) Chaque type écrit dans SA propre table
    switch (widget.contrat.type) {
      case 'location':
        await repository.linkContratToLocation(id, pdfUrl);
        break;
      case 'vente':
        await repository.linkContratToVente(id, pdfUrl);
        break;
      case 'echange':
        // ✅ Maintenant on écrit bien dans la table echanges
        await repository.linkContratToEchange(id, pdfUrl);
        break;
    }

    if (mounted) {
      NotificationService().success('Contrat enregistré avec succès !');
    }
  }
  
  Future<void> _sharePdf(File file) async {
    try {
      await SharePlus.instance.share(
        ShareParams(
          files: [XFile(file.path)],
          subject: 'Contrat ${widget.contrat.typeLabel} - ${widget.contrat.clientNom}',
        ),
      );
    } catch (e) {
      throw Exception('Erreur partage PDF: ${e.toString()}');
    }
  }
  
  @override
  Widget build(BuildContext context) {
    final (icon, color) = widget.contrat.typeInfo;
    final dateFormat = DateFormat('dd/MM/yyyy');
    final moneyFormat = NumberFormat('#,###', 'fr');
    
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: _isGenerating ? null : () => _generateAndDownloadPdf(),
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              // Icône du type
              Container(
                width: 48,
                height: 48,
                decoration: BoxDecoration(
                  color: color.withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: _isGenerating
                    ? const SizedBox(
                        width: 24,
                        height: 24,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      )
                    : Icon(icon, color: color, size: 24),
              ),
              
              const SizedBox(width: 16),
              
              // Informations
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          widget.contrat.typeLabel,
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: color,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: AppColors.background,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            dateFormat.format(widget.contrat.dateContrat),
                            style: const TextStyle(fontSize: 10, color: AppColors.textSecondary),
                          ),
                        ),
                        if (!widget.contrat.hasContract) ...[
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: Colors.orange.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(4),
                              border: Border.all(color: Colors.orange.withValues(alpha: 0.3)),
                            ),
                            child: const Text(
                              'Sans contrat',
                              style: TextStyle(fontSize: 10, color: Colors.orange, fontWeight: FontWeight.w600),
                            ),
                          ),
                        ],
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      widget.contrat.clientNom.isEmpty ? 'Client inconnu' : widget.contrat.clientNom,
                      style: AppTextStyles.heading3,
                    ),
                    const SizedBox(height: 2),
                    Text(
                      widget.contrat.vehiculeNom.isEmpty ? 'Véhicule inconnu' : widget.contrat.vehiculeNom,
                      style: AppTextStyles.bodySecondary.copyWith(fontSize: 12),
                    ),
                  ],
                ),
              ),
              
              // Montant et bouton
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${moneyFormat.format(widget.contrat.montant)} DA',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: color,
                    ),
                  ),
                  const SizedBox(height: 8),
                  if (!_isGenerating)
                    IconButton(
                      icon: Icon(
                        widget.contrat.hasContract ? Icons.download : Icons.picture_as_pdf,
                        size: 20,
                      ),
                      color: widget.contrat.hasContract ? color : Colors.orange,
                      tooltip: widget.contrat.hasContract ? 'Télécharger le PDF' : 'Générer le contrat',
                      onPressed: () => _generateAndDownloadPdf(),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}