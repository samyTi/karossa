// lib/features/more/presentation/more_screen.dart
// Page "Plus" avec navigation vers les fonctionnalités secondaires

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../core/constants/app_colors.dart';
import '../../auth/presentation/auth_provider.dart';

class MoreScreen extends ConsumerWidget {
  const MoreScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profile = ref.watch(currentProfileProvider).valueOrNull;
    final isGerant = profile?.isGerant ?? false;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Plus'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ── Finances ───────────────────────────────────────────
          _SectionHeader('Finances'),
          _MenuCard(items: [
            _MenuItem(Icons.account_balance_wallet_outlined,
              'Caisse', 'Entrées et sorties', AppColors.secondary,
              () => context.push('/caisse')),
            _MenuItem(Icons.analytics_outlined,
              'Relevé financier', 'Bilans et statistiques', AppColors.primary,
              () => context.push('/releve')),
          ]),
          const SizedBox(height: 12),

          // ── Transactions ───────────────────────────────────────
          _SectionHeader('Transactions'),
          _MenuCard(items: [
            _MenuItem(Icons.sell_outlined,
              'Ventes', 'Historique des ventes', AppColors.primary,
              () => context.push('/ventes')),
            _MenuItem(Icons.shopping_cart_outlined,
              'Achats', 'Véhicules achetés', AppColors.accent,
              () => context.push('/achats')),
            _MenuItem(Icons.swap_horiz,
              'Échanges', 'Reprises et échanges', AppColors.reserve,
              () => context.push('/echanges')),
          ]),
          const SizedBox(height: 12),

          // ── Entretien ──────────────────────────────────────────
          _SectionHeader('Maintenance'),
          _MenuCard(items: [
            _MenuItem(Icons.build_outlined,
              'Réparations', 'Suivi des réparations', AppColors.reparation,
              () => context.push('/reparations')),
            _MenuItem(Icons.notifications_outlined,
              'Alertes entretien', 'Vidanges, CT, assurances', AppColors.accent,
              () => context.push('/entretien')),
          ]),
          const SizedBox(height: 12),

          // ── GPS ────────────────────────────────────────────────
          _SectionHeader('GPS & Sécurité'),
          _MenuCard(items: [
            _MenuItem(Icons.gps_fixed,
              'Carte GPS', 'Position en temps réel', AppColors.primary,
              () => context.push('/gps/map')),
            _MenuItem(Icons.warning_amber_outlined,
              'Alertes GPS', 'Notifications boîtiers', AppColors.retard,
              () => context.push('/gps/alertes')),
          ]),
          const SizedBox(height: 12),

          // ── Admin ──────────────────────────────────────────────
          if (isGerant) ...[
            _SectionHeader('Administration'),
            _MenuCard(items: [
              _MenuItem(Icons.people_outlined,
                'Utilisateurs', 'Gérer les accès', AppColors.gerant,
                () => context.push('/admin/users')),
              _MenuItem(Icons.settings_outlined,
                'Paramètres', 'Configuration du showroom', AppColors.textSecondary,
                () => context.push('/settings')),
              _MenuItem(Icons.description_outlined,
                'Contrats / Templates', 'Modèles de documents', AppColors.primary,
                () => context.push('/contrats')),
            ]),
            const SizedBox(height: 12),
          ],

          // ── Compte ─────────────────────────────────────────────
          _SectionHeader('Mon compte'),
          _MenuCard(items: [
            _MenuItem(Icons.person_outline,
              'Mon profil', 'Informations personnelles', AppColors.primary,
              () => context.push('/profil')),
            _MenuItem(Icons.notifications_outlined,
              'Notifications', 'Centre de notifications', AppColors.accent,
              () => context.push('/notifications')),
          ]),
          const SizedBox(height: 80),
        ],
      ),
    );
  }
}

// ── Helpers ──────────────────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  final String text;
  const _SectionHeader(this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8, left: 2),
    child: Text(text,
      style: const TextStyle(
        fontSize: 12, fontWeight: FontWeight.w600,
        color: AppColors.textSecondary,
        letterSpacing: 0.5)),
  );
}

class _MenuCard extends StatelessWidget {
  final List<_MenuItem> items;
  const _MenuCard({required this.items});

  @override
  Widget build(BuildContext context) => Container(
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: AppColors.border),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withValues(alpha: 0.04),
          blurRadius: 6, offset: const Offset(0, 2)),
      ],
    ),
    child: Column(
      children: items.asMap().entries.map((e) {
        final isLast = e.key == items.length - 1;
        return Column(children: [
          e.value._buildTile(context),
          if (!isLast) const Divider(height: 1, indent: 56),
        ]);
      }).toList(),
    ),
  );
}

class _MenuItem {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;
  const _MenuItem(this.icon, this.title, this.subtitle, this.color, this.onTap);

  Widget _buildTile(BuildContext context) => ListTile(
    leading: Container(
      width: 36, height: 36,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Icon(icon, color: color, size: 20),
    ),
    title: Text(title,
      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
    subtitle: Text(subtitle,
      style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
    trailing: const Icon(Icons.chevron_right,
      color: AppColors.textHint, size: 18),
    onTap: onTap,
  );
}
