// lib/core/config/app_config.dart
// ⚠️  Ne pas committer ce fichier — ajoutez-le à .gitignore

class AppConfig {
  static const String supabaseUrl     = 'https://mkrbhyrkrajicthcqjtj.supabase.co';
  static const String supabaseAnonKey = 'sb_publishable_UyjVexlQkh_qO0yiPoiTuA_eJfdz23w';
}
